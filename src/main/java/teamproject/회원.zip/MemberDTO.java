package teamproject;

public class MemberDTO {
	private String email;
	private String pw;
	private String nick;
	private String mobile;
	private String infoagree;
	private String marketingagree;
	private String positionagree;
	private String username;
	private int point;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getInfoagree() {
		return infoagree;
	}
	public void setInfoagree(String infoagree) {
		this.infoagree = infoagree;
	}
	public String getMarketingagree() {
		return marketingagree;
	}
	public void setMarketingagree(String marketingagree) {
		this.marketingagree = marketingagree;
	}
	public String getPositionagree() {
		return positionagree;
	}
	public void setPositionagree(String positionagree) {
		this.positionagree = positionagree;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}

}
